//
//  UMSocialInstragramHandler.h
//  SocialSDK
//
//  Created by yeahugo on 14-1-8.
//  Copyright (c) 2014年 Umeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UMSocialInstagramHandler : NSObject

+(void)openInstagram;
@end
