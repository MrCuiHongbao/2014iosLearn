//
//  RennUbbService.h
//  RennSDK
//
//  Created by Li Chengliang on 13-4-10.
//  Copyright (c) 2013年 Li Chengliang. All rights reserved.
//

#import "RennParam.h"

extern NSString *kRennServiceTypeListUbb;

/*
 API链接: http://wiki.dev.renren.com/wiki/V2/ubb/list
 */
@interface ListUbbParam : RennParam

@end
