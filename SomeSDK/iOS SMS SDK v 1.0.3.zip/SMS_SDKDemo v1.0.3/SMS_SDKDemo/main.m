//
//  main.m
//  SMS_SDKDemo
//
//  Created by 严军 on 14-6-27.
//  Copyright (c) 2014年 严军. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YJAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YJAppDelegate class]));
    }
}
